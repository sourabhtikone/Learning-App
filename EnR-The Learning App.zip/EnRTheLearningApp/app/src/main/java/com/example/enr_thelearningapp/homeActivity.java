package com.example.enr_thelearningapp;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class homeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemReselectedListener(navListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragement,new SearchFragement()).commit();
    }
    private BottomNavigationView.OnNavigationItemReselectedListener navListener=
            new BottomNavigationView.OnNavigationItemReselectedListener() {
        @Override
        public void onNavigationItemReselected(@NonNull MenuItem item) {
            Fragment selectedFragment=null;
            switch (item.getItemId()){
                case R.id.nav_search:
                    selectedFragment=new SearchFragement();
                    break;
                case R.id.nav_account:
                    selectedFragment=new accountFragement();
                    break;
                case R.id.nav_mycourse:
                    selectedFragment=new mycourseFragement();
                    break;
                case R.id.nav_wishlist:
                    selectedFragment=new wishlistFragement();
                    break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragement,selectedFragment).commit();
            return ;

        }
    };
}